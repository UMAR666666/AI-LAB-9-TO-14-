# Diabetes Prediction Flask Web Application

## Project Overview
This is a Flask-based web application for diabetes risk prediction using machine learning. The application uses a pre-trained Logistic Regression model to assess the probability of diabetes based on patient health metrics.

## Features
- 🏥 User-friendly web interface
- 🤖 AI-powered diabetes risk assessment
- 📊 Confidence score and probability predictions
- 🎨 Responsive design for all devices
- 📱 Mobile-friendly interface

## Project Structure
```
Flask_App/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── templates/
│   ├── index.html        # Home page with prediction form
│   └── about.html        # About page with project information
└── static/
    ├── style.css         # Styling for the web application
    └── script.js         # JavaScript for form handling and predictions
```

## Prerequisites
- Python 3.7 or higher
- pip (Python package installer)

## Installation & Setup

### 1. Install Dependencies
Navigate to the Flask_App directory and install required packages:
```bash
pip install -r requirements.txt
```

### 2. Prepare Model Files
Ensure these files exist in the parent directory:
- `C:\Users\HAROON-CHISHTI\Desktop\Project\diabetes_model.pkl`
- `C:\Users\HAROON-CHISHTI\Desktop\Project\scaler.pkl`

These files should be generated from the Jupyter notebook by running the pickle save cells.

### 3. Run the Application
```bash
python app.py
```

The application will start at `http://localhost:5000`

## Usage

### Making Predictions
1. Open your web browser and navigate to `http://localhost:5000`
2. Fill in the patient information:
   - Gender (Female, Male, Other)
   - Age
   - BMI (Body Mass Index)
   - HbA1c Level
   - Blood Glucose Level
3. Answer questions about medical history:
   - Hypertension
   - Heart Disease
   - Smoking History
4. Click "Predict Diabetes Risk"
5. View the prediction result with confidence score

### Application Pages
- **Home** (`/`): Main prediction interface
- **Prediction API** (`/predict`): POST endpoint for predictions
- **About** (`/about`): Project information and disclaimer

## API Endpoints

### POST /predict
**Request Body:**
```json
{
    "gender": "Female",
    "age": 45,
    "bmi": 25.5,
    "HbA1c_level": 5.8,
    "blood_glucose_level": 110,
    "hypertension": 0,
    "heart_disease": 0,
    "smoking_history": "never"
}
```

**Response:**
```json
{
    "prediction": 0,
    "prediction_text": "Non-Diabetic",
    "probability": {
        "non_diabetic": 0.85,
        "diabetic": 0.15
    },
    "confidence": 85.0
}
```

## Model Information
- **Algorithm**: Logistic Regression
- **Training Data**: Diabetes Prediction Dataset
- **Features**: 11 input features
- **Target**: Binary classification (Diabetic/Non-Diabetic)

## Technical Stack
- **Backend Framework**: Flask (Python)
- **Machine Learning**: scikit-learn
- **Data Processing**: Pandas, NumPy
- **Frontend**: HTML, CSS, JavaScript
- **Model Format**: Pickle

## Important Disclaimer ⚠️
**This application is for educational and research purposes only.** It should NOT be used as a substitute for professional medical advice, diagnosis, or treatment. Always consult with a qualified healthcare professional for medical concerns.

## Author Information
- **Name**: Umar Farooq Khan
- **Subject**: AI Lab
- **Section**: BS-AI-3C
- **Roll Number**: 139

## Troubleshooting

### Model Files Not Found
- Ensure the pickle files are saved in the correct location
- Verify the paths in `app.py` match your system

### Port Already in Use
If port 5000 is already in use, modify the port in the last line of `app.py`:
```python
app.run(debug=True, host='localhost', port=5001)  # Change 5000 to another port
```

### Module Import Errors
Ensure all dependencies are installed:
```bash
pip install -r requirements.txt
```

## Future Enhancements
- Add more machine learning models (Random Forest, SVM, etc.)
- Implement user authentication
- Add data visualization for results
- Export prediction reports
- Add multilingual support

## License
Educational project - For learning purposes only.
