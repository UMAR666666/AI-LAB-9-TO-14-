document.getElementById('predictionForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    // Validate medical history
    const smokingHistory = document.getElementById('smoking_history').value;
    if (!smokingHistory) {
        showError('Please select a smoking history option');
        return;
    }
    
    // Get form data
    const formData = {
        gender: document.getElementById('gender').value,
        age: document.getElementById('age').value,
        bmi: document.getElementById('bmi').value,
        HbA1c_level: document.getElementById('HbA1c_level').value,
        blood_glucose_level: document.getElementById('blood_glucose_level').value,
        hypertension: document.getElementById('hypertension').checked ? 1 : 0,
        heart_disease: document.getElementById('heart_disease').checked ? 1 : 0,
        smoking_history: smokingHistory
    };

    // Show loading state
    const resultDiv = document.getElementById('result');
    const resultContent = document.getElementById('resultContent');
    resultContent.innerHTML = '<p>Processing prediction<span class="loading">...</span></p>';
    resultDiv.style.display = 'block';

    try {
        // Send prediction request
        const response = await fetch('/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        const data = await response.json();

        if (response.ok) {
            displayResult(data);
        } else {
            showError(data.error || 'An error occurred during prediction');
        }
    } catch (error) {
        showError('Network error: ' + error.message);
    }
});

function displayResult(data) {
    const resultContent = document.getElementById('resultContent');
    
    const predictionClass = data.prediction === 1 ? 'diabetic' : 'non-diabetic';
    const confidencePercentage = data.confidence.toFixed(2);
    const nonDiabeticProb = (data.probability.non_diabetic * 100).toFixed(2);
    const diabeticProb = (data.probability.diabetic * 100).toFixed(2);

    const html = `
        <div class="result-box">
            <div class="prediction-header">🔍 Prediction Result</div>
            <div class="prediction-result ${predictionClass}">
                ${data.prediction_text}
            </div>
            
            <div class="probability-info">
                <p><strong>Confidence Level:</strong> ${confidencePercentage}%</p>
                <p><strong>Non-Diabetic Probability:</strong> ${nonDiabeticProb}%</p>
                <p><strong>Diabetic Probability:</strong> ${diabeticProb}%</p>
            </div>

            <div class="confidence-bar">
                <div class="confidence-label">
                    <span>Confidence:</span>
                    <span>${confidencePercentage}%</span>
                </div>
                <div class="bar">
                    <div class="bar-fill" style="width: ${confidencePercentage}%"></div>
                </div>
            </div>

            <div style="background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 5px; margin-top: 15px;">
                <strong>⚠️ Medical Disclaimer:</strong>
                <p style="margin-top: 10px; font-size: 0.9em;">This prediction is for informational purposes only and should not be used as a substitute for professional medical advice. Please consult with a qualified healthcare professional for proper diagnosis and treatment.</p>
            </div>
        </div>
    `;

    resultContent.innerHTML = html;
}

function showError(errorMessage) {
    const resultContent = document.getElementById('resultContent');
    resultContent.innerHTML = `
        <div class="error">
            <strong>❌ Error:</strong> ${errorMessage}
        </div>
    `;
}

function resetForm() {
    document.getElementById('predictionForm').reset();
    document.getElementById('result').style.display = 'none';
}
