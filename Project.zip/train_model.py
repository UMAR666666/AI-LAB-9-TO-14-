"""
Script to train the diabetes model and save it as pickle files
Run this ONCE before starting the Flask app
"""

import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

# Load dataset
print("Loading dataset...")
df = pd.read_csv(r"C:\Users\HAROON-CHISHTI\Desktop\Project\diabetes.csv")

# Data preprocessing
print("Preprocessing data...")
X = df.drop('diabetes', axis=1)
y = df['diabetes']

# Convert categorical variables to numeric
X = pd.get_dummies(X, drop_first=True)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train model
print("Training model...")
log_model = LogisticRegression(max_iter=1000)
log_model.fit(X_train_scaled, y_train)

# Evaluate
from sklearn.metrics import accuracy_score
y_pred = log_model.predict(X_test_scaled)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy:.4f}")

# Save model
model_path = r"C:\Users\HAROON-CHISHTI\Desktop\Project\diabetes_model.pkl"
with open(model_path, 'wb') as file:
    pickle.dump(log_model, file)
print(f"✓ Model saved to {model_path}")

# Save scaler
scaler_path = r"C:\Users\HAROON-CHISHTI\Desktop\Project\scaler.pkl"
with open(scaler_path, 'wb') as file:
    pickle.dump(scaler, file)
print(f"✓ Scaler saved to {scaler_path}")

# Save feature names for prediction
feature_names_path = r"C:\Users\HAROON-CHISHTI\Desktop\Project\feature_names.pkl"
with open(feature_names_path, 'wb') as file:
    pickle.dump(X.columns.tolist(), file)
print(f"✓ Feature names saved to {feature_names_path}")

print("\n✓ All files saved successfully!")
print("You can now run the Flask app: python app.py")
